const urlAPI = 'http://localhost:13197/api/';

export {
  urlAPI
};